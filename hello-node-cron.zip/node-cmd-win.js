// or more concisely
var sys = require('sys')
var exec = require('child_process').exec;
function puts(error, stdout, stderr) { sys.puts(stdout) }
exec("dir /w", puts);
exec("dir /w > dirw.txt", puts);
exec("runme-win32.cmd", puts);
exec("SampleDotNetConApp.exe", puts);
exec("SampleDotNetConApp.exe > sampleoutput.txt", puts);
