var cron = require('node-cron');

console.log('Sample to print a message to the console every minute');

cron.schedule('* * * * *', function(){
  console.log(new Date().toISOString() +' running a task every minute');
});
